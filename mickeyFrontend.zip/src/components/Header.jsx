
import { useState } from "react";
import logo from "../assets/Mickey's_PrimaryLogo.svg";

import { Link } from "react-router-dom";
import { Menu, X } from "lucide-react";

const Header = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const closeMenu = () => {
        setIsMenuOpen(false);
    };

    return (
        <div>
            {/* Top Navigation Bar */}
            <header
                className="relative z-30 header-responsive"
                data-purpose="site-navigation"
            >
                {/* Logo */}
                <Link
                    aria-label="Mickey's Cafe home"
                    className="inline-flex items-center hover:opacity-95 transition-opacity"
                    to="/"
                >
                    <img
                        className="logo-img"
                        src={logo}
                        alt="Mickey's Cafe & Lounge"
                    />
                </Link>

                {/* Desktop Navigation */}
                <nav
                    aria-label="Main Navigation"
                    className="hidden md:flex items-center gap-4 sm:gap-8"
                >
                    <div className="nav-links">
                        <Link
                            className="text-[15px] font-semibold text-roast/90 hover:text-terracotta transition-colors tracking-normal"
                            to="/menu"
                        >
                            Menu
                        </Link>

                        <Link
                            className="text-[15px] font-semibold text-roast/90 hover:text-terracotta transition-colors tracking-normal"
                            to="/eventspage"
                        >
                            Events
                        </Link>

                        <Link
                            className="text-[15px] font-semibold text-roast/90 hover:text-terracotta transition-colors tracking-normal"
                            to="/gallerypage"
                        >
                            Gallery
                        </Link>

                        <Link
                            className="text-[15px] font-semibold text-roast/90 hover:text-terracotta transition-colors tracking-normal"
                            to="/ourstory"
                        >
                            Our Story
                        </Link>
                    </div>

                    <Link className="shop-btn" to="/login">
                        Sign in
                    </Link>
                </nav>

                {/* Mobile Menu Button */}
                <button
                    type="button"
                    onClick={() => setIsMenuOpen(true)}
                    className="md:hidden flex items-center justify-center w-11 h-11 text-roast"
                    aria-label="Open menu"
                >
                    <Menu size={27} strokeWidth={1.8} />
                </button>
            </header>

            {/* Mobile Overlay */}
            <div
                onClick={closeMenu}
                className={`fixed inset-0 z-40 bg-black/30 backdrop-blur-[2px] transition-opacity duration-300 md:hidden ${
                    isMenuOpen
                        ? "opacity-100 visible"
                        : "opacity-0 invisible"
                }`}
            />

            {/* Mobile Right Sidebar */}
            <aside
                className={`fixed top-0 right-0 z-50 h-screen w-[82%] max-w-[360px] bg-cream-50 shadow-2xl transition-transform duration-300 ease-out md:hidden ${
                    isMenuOpen
                        ? "translate-x-0"
                        : "translate-x-full"
                }`}
            >
                {/* Sidebar Header */}
                <div className="flex items-center justify-between px-6 py-5 border-b border-roast/10">
                    <Link to="/" onClick={closeMenu}>
                        <img
                            src={logo}
                            alt="Mickey's Cafe & Lounge"
                            className="w-[120px]"
                        />
                    </Link>

                    <button
                        type="button"
                        onClick={closeMenu}
                        className="flex items-center justify-center w-10 h-10 rounded-full text-roast hover:bg-cream-100 transition-colors"
                        aria-label="Close menu"
                    >
                        <X size={24} strokeWidth={1.8} />
                    </button>
                </div>

                {/* Sidebar Navigation */}
                <nav
                    aria-label="Mobile Navigation"
                    className="px-6 py-8"
                >
                    <div className="flex flex-col">

                        <Link
                            to="/menu"
                            onClick={closeMenu}
                            className="py-5 text-[18px] font-semibold text-roast border-b border-roast/10 hover:text-terracotta transition-colors"
                        >
                            Menu
                        </Link>

                        <Link
                            to="/#collections"
                            onClick={closeMenu}
                            className="py-5 text-[18px] font-semibold text-roast border-b border-roast/10 hover:text-terracotta transition-colors"
                        >
                            Events
                        </Link>

                        <Link
                            to="/#notes"
                            onClick={closeMenu}
                            className="py-5 text-[18px] font-semibold text-roast border-b border-roast/10 hover:text-terracotta transition-colors"
                        >
                            Gallery
                        </Link>

                        <Link
                            to="/ourstory"
                            onClick={closeMenu}
                            className="py-5 text-[18px] font-semibold text-roast border-b border-roast/10 hover:text-terracotta transition-colors"
                        >
                            Our Story
                        </Link>

                        {/* Sign In Button */}
                        <Link
                            to="/login"
                            onClick={closeMenu}
                            className="mt-8 flex items-center justify-center w-full rounded-full bg-terracotta text-white py-3.5 px-6 text-[15px] font-semibold hover:bg-terracotta-dark transition-all duration-200"
                        >
                            Sign in
                        </Link>
                    </div>
                </nav>
            </aside>
        </div>
    );
};

export default Header;

