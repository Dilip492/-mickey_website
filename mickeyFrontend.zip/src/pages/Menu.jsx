import { useMemo, useState } from "react";
import { Plus, Check } from "lucide-react";

import espresso from "../assets/espresso.webp";
import latte from "../assets/espresso.webp";
import cappuccino from "../assets/espresso.webp";
import avocadoToast from "../assets/espresso.webp";
import croissant from "../assets/espresso.webp";
import pasta from "../assets/espresso.webp";
import cheesecake from "../assets/espresso.webp";
import martini from "../assets/espresso.webp";
import Header from "../components/Header";

/* =========================================
   DATA
========================================= */
const categories = [
  "All",
  "Coffee",
  "Breakfast",
  "Bakery",
  "Mains",
  "Desserts",
  "Drinks",
];

const menuItems = [
  {
    id: 1,
    category: "Coffee",
    name: "Signature Espresso",
    description: "Rich espresso with deep chocolate and caramel notes.",
    price: "$4.50",
    image: espresso,
    tag: "Signature",
  },
  {
    id: 2,
    category: "Coffee",
    name: "Honey Cinnamon Latte",
    description: "Velvety espresso, steamed milk, honey and cinnamon.",
    price: "$6.25",
    image: latte,
  },
  {
    id: 3,
    category: "Coffee",
    name: "Classic Cappuccino",
    description: "Bold espresso balanced with silky steamed milk and foam.",
    price: "$5.75",
    image: cappuccino,
  },
  {
    id: 4,
    category: "Breakfast",
    name: "Avocado Toast",
    description: "Sourdough, smashed avocado, herbs and chili oil.",
    price: "$14.00",
    image: avocadoToast,
    tag: "Popular",
  },
  {
    id: 5,
    category: "Bakery",
    name: "Almond Croissant",
    description: "Buttery laminated pastry filled with almond cream.",
    price: "$5.50",
    image: croissant,
  },
  {
    id: 6,
    category: "Mains",
    name: "Truffle Mushroom Pasta",
    description: "Creamy wild mushrooms, parmesan and fresh herbs.",
    price: "$21.00",
    image: pasta,
    tag: "Chef's Pick",
  },
  {
    id: 7,
    category: "Desserts",
    name: "Basque Cheesecake",
    description: "Silky cheesecake with a beautifully caramelized top.",
    price: "$9.00",
    image: cheesecake,
  },
  {
    id: 8,
    category: "Drinks",
    name: "Espresso Martini",
    description: "Vodka, espresso and coffee liqueur.",
    price: "$14.00",
    image: martini,
  },
];

/* =========================================
   SUB-COMPONENT: Hero
========================================= */
function Hero() {
  return (
    <section className="bg-cream-100 px-6 py-16 md:px-12 md:py-24">
      <div className="mx-auto max-w-7xl">
        <p className="mb-3 font-sans text-sm font-bold uppercase tracking-[0.25em] text-terracotta">
          Mickey's Café &amp; Lounge
        </p>
        <h1 className="font-serif text-5xl leading-[0.95] md:text-7xl">
          Our Menu
        </h1>
        <p className="mt-6 max-w-2xl font-sans text-base leading-7 text-roast/60 md:text-lg">
          Crafted with quality ingredients, thoughtful flavours and a little
          bit of Mickey's magic.
        </p>
      </div>
    </section>
  );
}

/* =========================================
   SUB-COMPONENT: CategoryNav
========================================= */
function CategoryNav({ active, onChange }) {
  return (
    <nav
      aria-label="Menu categories"
      className="sticky top-0 z-40 border-b border-roast/10 bg-cream-50/95 backdrop-blur-md"
    >
      <div className="mx-auto max-w-7xl">
        <div
          role="tablist"
          className="scrollbar-hide flex overflow-x-auto px-6 md:px-12"
        >
          {categories.map((category) => {
            const isActive = active === category;
            return (
              <button
                key={category}
                role="tab"
                aria-selected={isActive}
                onClick={() => onChange(category)}
                className={`
                  relative shrink-0 px-5 py-5 font-sans text-sm font-semibold
                  transition-colors duration-200 md:px-7
                  focus:outline-none focus-visible:text-terracotta
                  ${isActive ? "text-terracotta" : "text-roast/55 hover:text-roast"}
                `}
              >
                {category}
                <span
                  aria-hidden="true"
                  className={`
                    absolute bottom-0 left-0 h-[3px] w-full origin-left
                    bg-terracotta transition-transform duration-300
                    ${isActive ? "scale-x-100" : "scale-x-0"}
                  `}
                />
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}

/* =========================================
   SUB-COMPONENT: ProductCard
========================================= */
function ProductCard({ item }) {
  const [added, setAdded] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleAdd = () => {
    setAdded(true);
    // TODO: hook into cart state here
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <article className="group flex flex-col">
      {/* IMAGE */}
      <div className="relative aspect-square overflow-hidden rounded-3xl bg-cream-200">
        {!imageLoaded && (
          <div className="absolute inset-0 animate-pulse bg-cream-200" />
        )}
        <img
          src={item.image}
          alt={item.name}
          loading="lazy"
          onLoad={() => setImageLoaded(true)}
          className={`
            h-full w-full object-cover
            transition-all duration-700 ease-out
            group-hover:scale-105
            ${imageLoaded ? "opacity-100 blur-0" : "opacity-0 blur-md"}
          `}
        />

        {item.tag && (
          <span className="absolute left-4 top-4 rounded-full bg-cream-50 px-4 py-2 font-sans text-[10px] font-bold uppercase tracking-wider text-terracotta shadow-sm">
            {item.tag}
          </span>
        )}
      </div>

      {/* INFO */}
      <div className="flex flex-1 flex-col pt-5">
        <div className="flex items-start justify-between gap-4">
          <div className="min-w-0">
            <p className="mb-1 font-sans text-xs font-semibold uppercase tracking-wider text-terracotta">
              {item.category}
            </p>
            <h3 className="font-serif text-2xl leading-tight text-roast transition-colors group-hover:text-terracotta">
              {item.name}
            </h3>
          </div>
          <span className="shrink-0 font-sans text-base font-bold text-roast">
            {item.price}
          </span>
        </div>

        <p className="mt-3 max-w-md font-sans text-sm leading-6 text-roast/55">
          {item.description}
        </p>

        <button
          onClick={handleAdd}
          aria-label={`Add ${item.name} to cart`}
          className={`
            mt-5 flex items-center gap-2 self-start rounded-full border px-5 py-2.5
            font-sans text-xs font-bold transition-all duration-200
            focus:outline-none focus-visible:ring-2 focus-visible:ring-terracotta
            focus-visible:ring-offset-2
            ${added
              ? "border-terracotta bg-terracotta text-white"
              : "border-roast/20 text-roast hover:border-terracotta hover:bg-terracotta hover:text-white"
            }
          `}
        >
          {added ? <Check size={15} /> : <Plus size={15} />}
          {added ? "Added" : "Add"}
        </button>
      </div>
    </article>
  );
}

/* =========================================
   SUB-COMPONENT: BottomCTA
========================================= */
function BottomCTA() {
  return (
    <section className="bg-roast px-6 py-20 text-center md:px-12 md:py-28">
      <span className="font-curved text-2xl text-terracotta-light">
        More than just coffee
      </span>
      <h2 className="mx-auto mt-4 max-w-3xl font-serif text-4xl leading-tight text-cream-50 md:text-6xl">
        Stay for the food.
        <br />
        <span className="italic text-terracotta-light">
          Stay for the moment.
        </span>
      </h2>
      <button
        className="
          mt-8 rounded-full bg-terracotta px-8 py-4 font-sans text-sm font-bold
          text-white transition hover:bg-terracotta-light
          focus:outline-none focus-visible:ring-2 focus-visible:ring-white
          focus-visible:ring-offset-2 focus-visible:ring-offset-roast
        "
      >
        Reserve a Table
      </button>
    </section>
  );
}

/* =========================================
   MAIN COMPONENT: Menu
========================================= */
export default function Menu() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredItems = useMemo(
    () =>
      activeCategory === "All"
        ? menuItems
        : menuItems.filter((item) => item.category === activeCategory),
    [activeCategory]
  );

  const heading =
    activeCategory === "All" ? "Everything we love" : activeCategory;

  return (

    <>
      <Header />
      <main className="min-h-screen bg-cream-50 text-roast main-container ">
        <Hero />

        <CategoryNav active={activeCategory} onChange={setActiveCategory} />

        {/* MENU CONTENT */}
        <section className="px-6 py-16 md:px-12 md:py-24">
          <div className="mx-auto max-w-7xl">
            <header className="mb-12">
              <span className="font-curved text-2xl text-terracotta">
                Made for you
              </span>
              <h2 className="mt-2 font-serif text-4xl md:text-5xl">
                {heading}
              </h2>
            </header>

            {filteredItems.length === 0 ? (
              <div className="rounded-3xl border border-dashed border-roast/15 py-20 text-center">
                <p className="font-serif text-2xl text-roast/60">
                  Nothing here yet.
                </p>
                <p className="mt-2 font-sans text-sm text-roast/45">
                  Try a different category.
                </p>
              </div>
            ) : (
              <div className="grid gap-x-10 gap-y-14 sm:grid-cols-2 lg:grid-cols-3">
                {filteredItems.map((item) => (
                  <ProductCard key={item.id} item={item} />
                ))}
              </div>
            )}
          </div>
        </section>

        <BottomCTA />
      </main>

    </>
  );
}